package exam;
//Q1. 배열은 ( ) 자료형을 순서대로 관리할 때 사용하는 자료 구조입니다.
public class Exam1 {
	public static void main(String[] args) {
		String answer = "똑같은";
		String query = "Q1. 배열은 ("+answer+") 자료형을 순서대로 관리할 때 사용하는 자료 구조입니다.";
		System.out.println(query);
	}
}
