/**
 * 
 */
/**
 * 
 */
module test06 {
}