package org.kh.object1;

public class Person {
	String name;
	int year;
	String gender;
	String job;
	void running(){
		System.out.println(this.name+"가 달립니다");
	}
}
