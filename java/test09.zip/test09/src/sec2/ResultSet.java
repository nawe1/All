package sec2;

public class ResultSet {

}
