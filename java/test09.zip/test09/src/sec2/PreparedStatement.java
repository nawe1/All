package sec2;

public class PreparedStatement {

}
