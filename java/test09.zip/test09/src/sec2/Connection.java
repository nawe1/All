package sec2;

public class Connection {

}
