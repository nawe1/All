package sec3;

public class Korean implements Lunch {
	@Override
	public void eating(String menu) {
		System.out.println("한식 : "+menu+"를 먹습니다.");
	}
}
