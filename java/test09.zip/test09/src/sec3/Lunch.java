package sec3;

public interface Lunch {
	void eating(String menu);
}
