package add;

public final class Terminal { //final 클래스 : 상속해 줄 수 없는 클래스 - 보안상 절대 알면 안되는 클래스, 사용해서도 안되는 클래스, 재사용해서도 안되는 클래스
	public int num1;
	public void method1() {
		System.out.println("Final 클래스 Terminal");
	}
}
