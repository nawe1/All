package add;

public class TourBus extends Bus {
	@Override
	public void method2() {
		super.method2();
	}
}
