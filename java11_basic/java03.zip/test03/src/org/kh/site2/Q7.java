package org.kh.site2;

public class Q7 {
	public static void main(String[] args) {
		int num = 10;
		int num2 = 20;
		
		int result = (num >= 10) ? num2 + 10 : num2 - 10;
		System.out.println(result); 	//30
	}
}