package org.kh.site2;

public class Q2 {
	public static void main(String[] args) {
		int num;
		num = -5 + 3 * 10 / 2;
		System.out.println(num);
	}
}
