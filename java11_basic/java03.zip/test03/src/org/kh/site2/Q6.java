package org.kh.site2;

public class Q6 {
	public static void main(String[] args) {
		int num = 8;
		//000000000000001000
		System.out.println(num += 10);	//18
		System.out.println(num -= 10);	//8
		System.out.println(num >>= 2);	//2
	}
}