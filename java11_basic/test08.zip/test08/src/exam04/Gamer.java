package exam04;

public interface Gamer {
	void run(int speed);
	void jump(int height);
	void turn(int angle);
	void show(String name);
}
