package sec4;

public class MarketExam {
	public static void main(String[] args) {
		Buy buy;
		buy = new Market();
		buy.buy();
		
		Sell sell;
		sell = new Market();
		sell.sell();
	}
}
