package sec4;

public class Pay extends Inventory {
	public void pay() {
		System.out.println("결제하기");
	}
}
