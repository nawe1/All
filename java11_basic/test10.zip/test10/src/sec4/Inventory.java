package sec4;

public class Inventory {
	public void inventory() {
		System.out.println("재고파악하기");
	}
}
