package sec4;

public interface Sell {
	void sell();
}
