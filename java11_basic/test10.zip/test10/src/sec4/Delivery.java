package sec4;

public interface Delivery extends Buy, Sell{
	void delivery();
}
