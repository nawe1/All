package sec4;

public interface Buy {
	void buy();
}
