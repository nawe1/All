package sec2;

public interface Screen extends RemoteControl {
	int light();
	int dark();
	int zoomin();
	int zoomout();
}
